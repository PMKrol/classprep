Informacje na temat instalacji bibliotek: http://www.arduino.cc/en/Guide/Libraries

hcsr04 -> https://github.com/Martinsos/arduino-lib-hc-sr04
