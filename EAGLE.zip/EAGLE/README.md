# EagleStuff

common.lbr <br>
The library includes devices that I use frequently. Mostly it is a collection of selected elements from other libraries, but often modified, e.g. by changing the size of the pads.

ulps <br>
Directory of Eagle with plugins, currently only pcb-gcode with settings. Its probably version 3.6.2.4 Copyright&copy; 2004 - 2014 by John Johnson Software, LLC. I don't know where I got it...
