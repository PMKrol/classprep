#include "nonvolatile.h"

#include "plugins/calculator.plugin.h"
 